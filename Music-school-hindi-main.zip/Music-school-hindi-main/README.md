# A music school project in NextJS

## Description
Seach "chai aur code" on youtube and watch it there

## contributon
No need to make any PR in this repo. Specially DO NOT touch the README.md file